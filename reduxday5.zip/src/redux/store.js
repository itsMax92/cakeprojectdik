import { createStore } from "redux";
import Chotu from "./reducers"

var store = createStore(Chotu)

export default store 