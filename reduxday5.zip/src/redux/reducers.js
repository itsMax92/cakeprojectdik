 function reducer(state={
     isloggedin : localStorage.token?true:false
 },action){
    switch(action.type){
        case "LOGIN" :{
             state = {...state}
            state.isloggedin = true
            return state
        }
        case "CHECKOUT":{
            state = {...state}
            state.cartitems = action.payload.cartitems
            state.price = action.payload.price
            return state
        }

        default : return state
    }
}

export default reducer