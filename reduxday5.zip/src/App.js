import Navbar from "./components/Navbar"

function App() {
  var videos = [
    { name: "Ncr days", imdb: 9.2, image: "ncrdays.jpeg" , minage:18 },
    { name: "Family Man", imdb: 8.1, image: "familyman.jpeg" , minage:13 },
    { name: "Ncr days", imdb: 9.2, image: "ncrdays.jpeg" },
    { name: "Family Man", imdb: 8.1, image: "familyman.jpeg" },
  ]
  return (
    <>
      <Navbar />
      <div className="row">
        {
          videos.map((each) => {
            return (
              <div className="col mt-5">
                <img style={{ height: "18rem", width: "18rem" }} src={each.image}></img>
                <div>
                  <label>{each.name}</label>
                </div>
                {each.minage>=18 &&  <div>
                  <h5>A</h5>
                </div>}
                <div>
                  <label>{each.imdb}</label>
                </div>
              
              </div>
            )
          })
        }
      </div>

    </>
  )
}

export default App



