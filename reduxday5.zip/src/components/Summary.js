import { useSelector } from "react-redux"
import { Link } from "react-router-dom"

function Summary(){
    var cakes = useSelector(state=>state.cartitems)
    var price = useSelector(state=>state.price)
    return <>
    <h1>Order Summary</h1>
    {cakes?.length} cakes for {price} Rs

    <div>
        <Link to="address"><button className="btn btn-primary">Next</button></Link>
    </div>
    </>
}

export default Summary