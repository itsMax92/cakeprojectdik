function Admin() {
    return <>
        <h1>
            Admin Component
        </h1>
    </>
}

export default Admin