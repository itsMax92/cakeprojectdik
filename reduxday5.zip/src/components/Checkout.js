import { Outlet } from "react-router";
import { Link } from "react-router-dom";
function Checkout() {
    return (
        <div className="container">
            <div className="row">
                <div className="col-4">
                    <ul class="list-group">
                        <li class="list-group-item">
                            <Link to="summary"><h5>Summary</h5></Link>
                        </li>
                        <li class="list-group-item">
                            <Link to="address"><h5>Add Address</h5></Link>
                        </li>
                        
                        <li class="list-group-item">
                            <Link to="payment"><h5>Payment</h5></Link>
                        </li>
                        
                        
                    </ul>
                    <div>
                    </div>
                    
                </div>
                <div className="col-8">
                    <Outlet></Outlet>
                </div>
            </div>
        </div>
    )
}

export default Checkout