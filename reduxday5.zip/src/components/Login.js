import axios from "axios"
import { Link } from "react-router-dom"
import {useNavigate} from "react-router"
import { useState } from "react"
import Loader from "./Loader"
import { useDispatch } from "react-redux"

function Login(props) {
    var user = {}
    var dispatch = useDispatch()
    var navigate = useNavigate()
    var [isloading,setIsloading] = useState(false)
    function handleEmail(e) {
        user.email = e.target.value
    }

    function handlePassword(e) {
        user.password = e.target.value
    }
    function login() {
        var regex = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$/
        if (regex.test(user.email)) {
        setIsloading(true)

            axios({
                method:"post",
                url:"https://apifromashu.herokuapp.com/api/login",
                data:user
            }).then((response)=>{
        setIsloading(false)

                console.log("response from login api",response)
                if(response.data.token){
                    localStorage.token = response.data.token
                    dispatch({
                        type:"LOGIN"
                    })
                    navigate("/")
                    // navigate to home path 
                    // for that we will use useNavigate() hook
                }

            }).catch((error)=>{
                setIsloading(false)
            })
        }
        else {
            alert("Email is invalid")
        }
        console.log("User has entered this data", user)
    }
    return (
        <>
            <div style={{ width: "50%", margin: "auto" }} className="col-10">
               
                <div style={{ width: "50%", margin: "auto" }} >
                    <h1>Login Here</h1>
                    <div className="form-group mt-1">
                        <label>Email</label>
                        <input onChange={handleEmail} className="form-control"></input>
                    </div>
                    <div className="form-group mt-1">
                        <label>Password</label>
                        <input onChange={handlePassword} type="password" className="form-control"></input>
                    </div>
                    <div className="mt-1">
                        <Link to="/signup">New User? Signup Here</Link>
                        <Link to="/forgot" style={{float:"right"}}>Forgot Password?</Link>
                    </div>
                    <div className="mt-1">
                       {!isloading &&  <button onClick={login} className="btn btn-primary">Login</button>}
                      {isloading &&   <button disabled className="btn btn-primary">Loggingin Please Wait....</button>}
                    </div>
                </div>
            </div>
        </>
    )
}

export default Login