function User(props){
    console.log("......props" , props)
    return (
        <>
        </>
    )
}

export default User