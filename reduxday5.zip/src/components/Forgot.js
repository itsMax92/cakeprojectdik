function Forgot() {
    var user = {}
    function handleEmail(e){
        user.email = e.target.value
    }
    function recover(){
            console.log("User has entered" , user)
    }
    return <>
       <div style={{ width: "50%", margin: "auto" }} className="col-10">
                <div style={{ width: "50%", margin: "auto" }} >
                    <h1> Password Recovery</h1>
                    <div className="form-group mt-1">
                        <label>Email</label>
                        <input onChange={handleEmail} className="form-control"></input>
                    </div>
                    
                    <div className="mt-1">
                        <button onClick={recover} className="btn btn-primary">Submit</button>
                    </div>
                </div>
            </div>
        
    </>
}

export default Forgot