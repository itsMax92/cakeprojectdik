function Pagenotfound() {
    return (
        <>
            <div className="container">
                <img src="404.png"></img>

            </div>
        </>
    )
}

export default Pagenotfound