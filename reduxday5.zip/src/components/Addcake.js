function AddCake() {
    return <>
        <h1>Add Cake Component</h1>
    </>
}

export default AddCake