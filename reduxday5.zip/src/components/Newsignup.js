import React from "react"

class Signupstatefull extends React.Component{
    email
    constructor(){
        super()
        this.state = {
            error:null
        }
    }
    getStarted =()=>{
        console.log("....." , this.state)
        console.log(this.email,"......")
        if(this.email=="" || this.email==undefined){
            this.setState({
                error:"Email is required"
            })
        }
    }
    getEmail = (e)=>{
        this.email =  e.target.value
    }
    render(){
        return (
            <div>
                <input onChange={this.getEmail}  className="form-control" placeholder="Email"></input>
               {this.state.error}
                <button className="btn btn-danger" onClick = {this.getStarted}>Get Started</button>
            </div>
        )
    }  
}
export default Signupstatefull