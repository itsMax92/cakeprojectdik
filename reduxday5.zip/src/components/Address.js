function Address() {
    function addAddress(){

    }
    return <>
        <div className="container">
            <div style={{width:"50%",margin:"auto"}}>
                <h1>Add Address</h1>
                <div className="form-group">
                    <label>Name</label>
                    <input className="form-control"></input>
                </div>
                <div className="form-group mt-3">
                    <label>Address</label>
                    <input className="form-control"></input>
                </div>
                <div className="form-group mt-3">
                    <label>City</label>
                    <input className="form-control"></input>
                </div>
                <div className="form-group mt-3">
                    <label>Pincode</label>
                    <input className="form-control"></input>
                </div>
                <div className="form-group mt-3">
                    <label>Phone</label>
                    <input className="form-control"></input>
                </div>
                <div className="mt-3">
                    <button className="btn btn-primary" onClick={addAddress}>Add Address</button>
                </div>
            </div>

        </div>
    </>
}

export default Address