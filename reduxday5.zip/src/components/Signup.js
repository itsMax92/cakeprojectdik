import axios from "axios"

function Signup() {
    var user = {}
    function handleEmail(e) {
        user.email = e.target.value
    }
    function handleName(e) {
        user.name = e.target.value
    }
    function handlePassword(e) {
        user.password = e.target.value
    }
    function register() {
        var regex = /^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$/
        if(regex.test(user.email)){
            alert("Email is valid")
            axios({
                method:"post",
                url:"https://apifromashu.herokuapp.com/api/register",
                data:user
            }).then((response)=>{
                console.log("Response from signup api", response)
            },(error)=>{
                console.log("Error from signup api" , error)
            })
        }
        else{
            alert("Email is invalid")
        }
        console.log("User has entered this data" , user)
        
    }
    return (
        <>
            <div style={{width:"50%",margin:"auto"}} className="col-10">
                <div style={{width:"50%",margin:"auto"}} >
                <h1>Signup Here</h1>
                <div className="form-group mt-1">
                    <label>Email</label>
                    <input onChange={handleEmail} className="form-control"></input>
                </div>
                <div className="form-group mt-1">
                    <label>Name</label>
                    <input onChange={handleName} className="form-control"></input>
                </div>
                <div className="form-group mt-1">
                    <label>Password</label>
                    <input onChange={handlePassword} type="password" className="form-control"></input>
                </div>
                <div className="mt-1">
                <button onClick={register} className="btn btn-primary">Signup</button>
                </div>
            
                </div>
</div>
        </>
    )
}

export default Signup