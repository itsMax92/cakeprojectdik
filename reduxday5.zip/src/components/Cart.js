import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faTrash } from '@fortawesome/free-solid-svg-icons'

import axios from "axios"
import { useEffect, useRef, useState } from "react"
import { useDispatch } from "react-redux"
import { useNavigate } from "react-router"
import Loader from "./Loader"

function Cart() {
    var quantityref = useRef()
    var dispatch = useDispatch()
    var navigate = useNavigate()
    var price = 0
    var [cartitems, setCartitems] = useState([])
    function checkout(){
        // dispatch here type "CHECKOUT"
        dispatch({
            type:"CHECKOUT",
            payload:{
                cartitems:cartitems,
                price:price
            }
        })
        navigate("/checkout")
    }
    function increment(){
           
    }
    function decrement(){

    }
    useEffect(() => {
        axios({
            method: "get",
            url: "https://apifromashu.herokuapp.com/api/cakecart",
            headers: {
                authtoken: localStorage.token
            }
        }).then((response) => {
            console.log("Response fom getting cart items", response)
            setCartitems(response.data.data)
        })
    }, [])
    if(cartitems.length>0){
        return <>
        <div className="container">
            <h1>Your Cart Items</h1>
            <div className="mt-3">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Image</th>
                        <th scope="col">Price</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Remove</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        cartitems.map((each, index) => {
                            price+=each.price*each.quantity
                            return (
                                <tr>
                                    <th scope="row">{index + 1}</th>
                                    <td>{each.name}</td>
                                    <td><img src={each.image} style={{ height: "4rem", width: "4rem" }}></img></td>
                                    <td>{each.price}</td>
                                    <td ref={quantityref}><button onClick={increment} className="btn btn-light">+</button>{each.quantity}<button onClick={decrement} className="btn btn-light">-</button></td>
                                    <td><button className="btn btn-danger"><FontAwesomeIcon icon={faTrash}></FontAwesomeIcon></button></td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            <div>
              <button onClick={checkout} className="btn btn-warning">Checkout</button>  
              <h3>Total Price :{price}</h3>  
            </div>
            </div>
        </div>
    </>
    }
    else{
        return <Loader />
    }
    
}

export default Cart