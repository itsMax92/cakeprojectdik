import { useParams } from "react-router";

function Cakedetails() {
    var params = useParams()
    var cakeid = params.cakeid

    return (
        <>
            We will show details of this  <h1>{cakeid}</h1>  here
        </>
    )
}

export default Cakedetails