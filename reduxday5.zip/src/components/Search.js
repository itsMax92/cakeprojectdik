import axios from "axios"
import { useEffect, useState } from "react"
import { useSearchParams } from "react-router-dom"
import Cake from "./Cake"
import Loader from "./Loader"

function Search() {
    var [query,setQuery] =  useSearchParams()
    var [searchresults,setSearchresults] =  useState([])
    var [isloading,setIsloading] =  useState(false)
    var text = query.get("q")

    useEffect(()=>{
        setIsloading(true)
            axios({
                method:"get",
                url:"https://apifromashu.herokuapp.com/api/searchcakes?q="+text
            }).then((response)=>{
                setIsloading(false)
                setSearchresults(response.data.data)
            }).catch((error)=>{
                setIsloading(false)
            })
    },[text])
    return <>
        <h1>
            Search results for {text}
            <div>
            {isloading && <Loader />}
            <div style={{marginLeft:"1rem"}} className="row">
                {searchresults.map((each) => {
                    return <Cake data={each} />
                })}
            </div>

        </div>
        </h1>
    </>
}

export default Search