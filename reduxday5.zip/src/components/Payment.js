function Payment(){
    return (
        <>
        <h3>We Only accept Cash On Delivery as of now.</h3>
        <button className="btn btn-primary">Confirm Order</button>
        </>
    )
}

export default Payment