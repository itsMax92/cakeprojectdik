import axios from "axios"
import { useEffect, useState } from "react"
import Cake from "./Cake"
import Carousel from "./Carousel"
import Loader from "./Loader"
function Home() {
    // var [property,setProperty] =  useState(initialvalue)
    var [cakes, setCakes] = useState([])
    var [isloading,setIsloading] = useState(false)
     useEffect(()=>{
        setIsloading(true)
        axios({
            method: "get",
            url: "https://apifromashu.herokuapp.com/api/allcakes"
        }).then((response) => {
            setIsloading(false)
            setCakes(response.data.data)
        }).catch((error)=>{
            setIsloading(false)
        })
     },[])

    

    return (
        <div>
            {isloading && <Loader />}
            <Carousel />
            <div style={{marginLeft:"1rem"}} className="row">
                {cakes.map((each) => {
                    return <Cake data={each} />
                })}
            </div>

        </div>
    )
}

export default Home



// When u get the response from cakes api keep that into store 
// so that  it should take the data from store instead of api 