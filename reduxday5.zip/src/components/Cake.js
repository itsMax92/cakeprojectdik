import { useNavigate } from "react-router"

function Cake(props){
    console.log("....."  , props)
    var navigate = useNavigate()
    var data = props.data

    function showDetails(){
        var path = "/details/"+props.data.cakeid
        navigate(path)
    }
    return (
        <div class="card m-3" style={{width: "18rem"}}>
        <img onClick={showDetails} style={{height:"13rem"}} src={data.image} class="card-img-top" alt="..." />
        <div class="card-body">
          <h5 class="card-title">{data.name}</h5>
          <p class="card-text">{data.price}</p>
        </div>
      </div>
    )
}

export default Cake