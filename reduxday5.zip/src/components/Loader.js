import "./Loader.css"
function Loader(){
    return <div className="loading">

    </div>
}

export default Loader