import { useState } from "react"
import { BrowserRouter, Route, Routes } from "react-router-dom"
import AddCake from "./Addcake"
import Address from "./Address"
import Admin from "./Admin"
import Cakedetails from "./Cakedetail"
import Cart from "./Cart"
import Checkout from "./Checkout"
import Forgot from "./Forgot"
import Home from "./Home"
import Login from "./Login"
import Navbar from "./Navbar"
import Pagenotfound from "./Pagenotfound"
import Payment from "./Payment"
import Search from "./Search"
import Signup from "./Signup"
import Summary from "./Summary"


function MyRouter() {
  
    return (
        <>
            
            <BrowserRouter>
            <Navbar  />
                <Routes>
                    <Route path="/" element={<Home />}></Route>
                    <Route path="/login" element={<Login/>}></Route>
                    <Route path="/signup" element={<Signup />}></Route>
                    <Route path="/admin" element={<Admin />}></Route>
                    <Route path="/search" element={<Search />}></Route>
                    <Route path="/forgot" element={<Forgot />}></Route>
                    <Route path="/cart" element={<Cart />}></Route>
                    <Route path="/checkout" element={<Checkout/>}>
                        <Route path="" element={<Summary />} />
                        <Route path="address" element={<Address />} />
                        <Route path="summary" element={<Summary />} />
                        <Route path="payment" element={<Payment />} />
                    </Route>
                    <Route path="/details/:cakeid" element={<Cakedetails />}></Route>
                    <Route path="/addcake" element={<AddCake />}></Route>
                    <Route path="/*" element={<Pagenotfound />}></Route>

                </Routes>
            </BrowserRouter>
        </>
    )

}

export default MyRouter