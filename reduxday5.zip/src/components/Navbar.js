import { Link } from "react-router-dom"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSearch , faCartShopping , faSignOut } from '@fortawesome/free-solid-svg-icons'
import {useNavigate} from "react-router"
import { useSelector } from "react-redux"

function Navbar(props) {
    var navigate = useNavigate()
    var isloggedin = useSelector(state=>state.isloggedin)
    var searchtext
    function search(e) {
        e.preventDefault()
        if(searchtext){
            var path = "/search?q="+searchtext
            navigate(path)
        }
      
    }
    function getText(e) {
        console.log("....", e.target.value)
        searchtext = e.target.value
    }

    function logout(){
        localStorage.clear()
        window.location.href = "/"
    }
    
    var title = "Cake Gallery"
    return (
        <>
            <nav style={{ backgroundColor: "#0a0704 !important" }} class="navbar navbar-expand-lg bg-light">
                <div class="container-fluid">
                    <Link class="navbar-brand" to="/">{title}</Link>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                            <form class="d-flex" role="search">
                                <input onChange={getText} class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                                
                                    <button onClick={search} class="btn btn-outline-success" type="submit"><FontAwesomeIcon icon={faSearch}></FontAwesomeIcon></button>
                               
                            </form>


                        </ul>
                        <div class="d-flex">
                          {isloggedin==false && <Link to="/login">
                                <button class="btn btn-primary" type="submit">Login</button>

                            </Link> }
                            {isloggedin==true && <div>
                                <Link to="/cart"><button style={{marginRight:"1rem"}} class="btn btn-warning" type="submit"><FontAwesomeIcon icon={faCartShopping}></FontAwesomeIcon></button></Link>
                                
                                <button onClick={logout} class="btn btn-danger" type="submit"><FontAwesomeIcon icon={faSignOut}></FontAwesomeIcon></button>
                            
                                </div>

                            
                     }
                        </div>
                    </div>
                </div>
            </nav>
        </>
    )
}

export default Navbar


//http://localhost:5000/search?q=cheese